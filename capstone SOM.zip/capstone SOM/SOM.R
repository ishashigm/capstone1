# Load the required package
#Thanks to Shane for SOM pointers
#http://www.shanelynn.ie/self-organising-maps-for-customer-segmentation-using-r/

library(sqldf)
library(ggplot2)
require(kohonen)

#Read the data
rawData = read.csv("E:\\Research\\Customer Analytics\\OnlineRetailRFM.csv")
#Create training data set. Remove Customer ID - CID
sData = rawData[,2:4]
som_grid <- somgrid(xdim = 20, ydim=20, topo="hexagonal")
#Scale the data set
sDataMatrix = as.matrix(scale(sData))

#Build the SOM model
som_grid <- somgrid(xdim = 10, ydim=10, topo="hexagonal")
som_model <- som(sDataMatrix, 
                 grid=som_grid, 
                 rlen=500, 
                 alpha=c(0.05,0.01), 
                 keep.data = TRUE )

#Visualize the SOM maps
plot(som_model, type="changes")
plot(som_model, type="count", main="Node Counts")
plot(som_model, type="dist.neighbours", main = "SOM neighbour distances")
plot(som_model, type="codes")

#Meta-clustering SOM clusters using kmeans
mydata <- som_model$codes 
wss <- (nrow(mydata)-1)*sum(apply(mydata,2,var)) 
for (i in 2:15) {
  wss[i] <- sum(kmeans(mydata, centers=i)$withinss)
}
plot(wss, type="l")

## use hierarchical clustering to cluster the codebook vectors
som_cluster <- cutree(hclust(dist(som_model$codes)), 5)

# plot these results
pretty_palette <- c("#1f77b4", '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b', '#e377c2')
plot(som_model, type="mapping", bgcol = pretty_palette[som_cluster], main = "Clusters") 
add.cluster.boundaries(som_model, som_cluster)
